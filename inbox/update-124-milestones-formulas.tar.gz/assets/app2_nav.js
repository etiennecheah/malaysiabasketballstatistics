/* ---------------------------- chrome ---------------------------- */
const SITE = 'HOOPSTATS MY';
// the header's own icons (the phone layer's set lives in PH)
const NAV_IC = (() => {
  const i = d => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;
  return { search: i('M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5.2-5.2'),
    help: i('M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM9.6 9.3a2.5 2.5 0 0 1 4.8 1c0 1.7-2.4 2.2-2.4 3.7M12 17.2v.1'),
    sun: i('M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4'),
    moon: i('M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z') };
})();

function navShell(links, sub) {
  // which page of the Tools menu is open, so the menu can mark it
  const h = HS.hash();
  const statsPage = /^#\/stats/.test(h) ? (/^#\/stats\/clutch/.test(h) ? 'clutch' : 'lineups')
    : /^#\/compare\/lineups/.test(h) ? 'cmp-lineups' : /^#\/compare/.test(h) ? 'cmp-players' : /^#\/wowy/.test(h) ? 'wowy' : /^#\/shift/.test(h) ? 'shift' : /^#\/scouting/.test(h) ? 'scouting' : /^#\/milestones/.test(h) ? 'milestones' : /^#\/formulas/.test(h) ? 'formulas' : '';
  return `
  <a class="skip-link" href="#main" data-skip>Skip to content</a>
  <nav class="nav" aria-label="Site">
    <div class="nav-left">
      <a href="#/" class="wordmark" aria-label="HoopStatsMY, home"><span class="dot"></span><span class="wm-t">HOOPSTATS</span><span class="wm-my">MY</span></a>
      <div class="nav-links">${links}</div>
    </div>
    <div class="nav-right">
      <button type="button" class="hs-sbtn" data-hs-search aria-label="Search players, teams and competitions" aria-keyshortcuts="/ Control+K">${NAV_IC.search}<span class="hs-sbtn-t">Search players, teams…</span><kbd>/</kbd></button>
      <button type="button" class="nav-ic nav-help" data-hsg-open aria-label="Guide: how to use HoopStatsMY" title="How to use HoopStatsMY">${NAV_IC.help}</button>
      ${typeof accNav === 'function' ? accNav() : ''}
      <button class="theme-toggle" data-theme-toggle="1" title="Switch between the light and dark theme" aria-label="Switch theme">
        <span class="sun">${NAV_IC.sun}</span><span class="moon">${NAV_IC.moon}</span>
      </button>
    </div>
    ${typeof STATS !== 'undefined' ? STATS.navMenu(statsPage) : ''}
  </nav>
  ${typeof liveBar === 'function' ? liveBar() : ''}
  ${sub}
  ${typeof PH !== 'undefined' ? PH.bar() : ''}`;
}
function subnav(label, crumb, links) {
  return `<div class="subnav" role="navigation" aria-label="Section"><div class="subnav-inner">
    <div class="subnav-eyebrow"><span class="subnav-label">${esc(label)}</span>${crumb ? `<span class="subnav-sep">·</span>${crumb}` : ''}</div>
    ${links && links.length ? `<div class="subnav-links">${links.map(([h, t, a]) => `<a href="${h}" class="subnav-link ${a ? 'active' : ''}">${esc(t)}</a>`).join('')}</div>` : ''}
  </div></div>`;
}

function siteLinks(state) {
  return [['#/', 'Today', state === 'home' || state === 'live'],
          ['mbl', typeof MB !== 'undefined' ? MB.tabLabel() : 'MBL', state === 'mbl'],
          ['#/players', 'Players', state === 'global-players' || state === 'player'],
          ['#/competitions', 'Competitions', state === 'hub' || state === 'notfound' || state === 'comp' || state === 'cfam'],
          ['#/teams', 'Teams', state === 'teams-hub' || state === 'team-global'],
          ['#/records', 'Records', state === 'records'],
          // a button: it opens the Tools menu (Lineups, Clutch, Compare, and Milestones and Formulas at its foot)
          ['stats', 'Tools', state === 'stats' || state === 'compare' || state === 'wowy' || state === 'shift' || state === 'scouting' || state === 'milestones' || state === 'formulas']]
    .map(([h, t, a]) => h === 'stats' ? (typeof STATS !== 'undefined' ? STATS.navButton(a) : '')
      // the current MBL season, with a small pulsing dot
      : h === 'mbl' ? `<a href="#/mbl" class="nav-link nav-mbl ${a ? 'active' : ''}"><i aria-hidden="true"></i>${esc(t)}</a>`
      : `<a href="${h}" class="nav-link ${a ? 'active' : ''}">${esc(t)}</a>`).join('');
}

function renderNav(state, cid, tab) {
  // Site-level pages — everything that isn't inside one competition. The Teams hub
  // and a team's own page belong here too; left out, they fell through to the
  // competition bar with no competition behind it.
  if (!cid || state === 'hub' || state === 'global-players' || state === 'player' || state === 'compare'
      || state === 'formulas' || state === 'notfound'
      || state === 'teams-hub' || state === 'team-global' || state === 'cfam'
      || state === 'home' || state === 'live' || state === 'me' || state === 'stats' || state === 'milestones' || state === 'records' || state === 'wowy' || state === 'shift' || state === 'scouting' || state === 'mbl') {
    const links = siteLinks(state);
    const label = state === 'stats' || state === 'compare' || state === 'wowy' || state === 'shift' || state === 'scouting' ? 'Tools' : state === 'formulas' ? 'Formulas'
      : (state === 'teams-hub' || state === 'team-global') ? 'Teams'
      : (state === 'global-players' || state === 'player') ? 'Players' : 'Competitions';
    const crumb = state === 'stats'
      ? '<span class="subnav-crumb" id="st-crumb"></span>'
      : state === 'compare'
      ? '<span class="subnav-crumb">Compare · two players, or two teams\' lineups, inside a competition they both played</span>'
      : state === 'formulas'
      ? '<span class="subnav-crumb">what every abbreviation means, and where the number comes from</span>'
      : state === 'wowy'
      ? '<span class="subnav-crumb">WOWY · every on/off mix of up to five players, men’s Agong Cup and MBL</span>'
      : state === 'scouting'
      ? '<span class="subnav-crumb">Scouting reports · plays tagged by hand from game film</span>'
      : state === 'shift'
      ? '<span class="subnav-crumb">Stat Line Shift · one player’s line with and without his teammates, men’s Agong Cup and MBL</span>'
      : `<span class="subnav-crumb">Malaysia basketball database · ${COMPS.length} competitions</span>`;
    // a player's page opens straight into its own full-width hero
    return navShell(links, state === 'player' || state === 'cfam' || state === 'home' || state === 'live' || state === 'me' || state === 'milestones' || state === 'records' || state === 'mbl' || state === 'help' || state === 'team-global' || state === 'stats' || state === 'wowy' || state === 'shift' || state === 'formulas' ? '' : subnav(label, crumb, []));
  }
  // Competition-scoped pages: the site bar, with Competitions lit. The sections of
  // the competition are tabs in the page's own header (compHeader); a team or a
  // box score inside it keeps a crumb back to the competition.
  const c = COMP_BY_ID[cid];
  const links = siteLinks('comp');
  const inHeader = ['dashboard', 'standings', 'schedule', 'teams', 'players', 'leaders'].includes(state);
  return navShell(links, inHeader ? '' : subnav('Competitions', `<a href="#/c/${cid}" class="subnav-crumb subnav-crumb-link">${esc(c ? c.name : '')}</a>`, []));
}

// the same every time: worked out once (the first number formatting starts the locale data, slow on a phone)
let FOOTER = null;
function renderFooter() {
  // the footer with links (app4zm_help.js); the plain note stays as the fallback
  if (typeof HELP !== 'undefined') return FOOTER || (FOOTER = HELP.footer());
  return FOOTER || (FOOTER = `<footer class="footer-note">
    ${SITE} — a database of Malaysian basketball competitions. ${COMPS.length} competitions, ${Object.keys(PERSONS).length.toLocaleString()} players and ${COMPS.reduce((a, c) => a + c.nGames, 0).toLocaleString()} fixtures, all sourced from the MABA / Genius Sports competition portal. Every figure shown is the source's own published value or a total/percentage computed from it, and gaps in the source are labelled rather than filled in. The exception is the player Advanced tab, where PER, usage, Win Shares and BPM are computed here from box scores — Win Shares and BPM are models, their numbers are estimates, and the tab says so and shows their uncertainty.
  </footer>`);
}

/* ---------------------------- router ---------------------------- */
/* Moving between the tabs of one player's profile keeps the reader where they are: the tab bar
   is sticky, so a reader below it lands with the bar still in place and the new tab's content
   starting just under it; a reader above it stays exactly where they were. Any other move
   (a new page, another player) starts at the top. */
let ROUTE_PID = null;
function pvKeepScroll(y) {
  const pg = document.querySelector('.pv-page'), nav = document.querySelector('.pv-tabs');
  if (!pg || !nav) return window.scrollTo(0, 0);
  const natural = pg.getBoundingClientRect().top + window.scrollY, stick = parseFloat(getComputedStyle(nav).top) || 0;
  window.scrollTo(0, Math.min(y, Math.max(0, natural - stick)));
}
const ROUTE_NO_BOX = /^(|home|mbl|players|competitions|teams|live|me|admin|privacy|help)$/;
let ROUTE_DRAWN = false;
function route() {
  const hash = HS.hash().replace(/^#/, '') || '/';
  const parts = hash.split('/').filter(Boolean).map(decodeURIComponent);
  const app = document.getElementById('app');
  const samePlayer = parts[0] === 'p' && !!parts[1] && ROUTE_PID === parts[1], keepY = window.scrollY;
  ROUTE_PID = parts[0] === 'p' ? parts[1] : null;
  CREST_CID = parts[0] === 'c' ? parts[1] : null;   // an edition's own crests (EDITION_LOGO)
  let state = 'hub', cid = null, tab = '', body = '';

  // A profile link minted before two duplicate records were merged still points at
  // the id that lost; send it to the survivor rather than showing "player not found".
  if (parts[0] === 'p' && PALIAS[parts[1]]) {
    parts[1] = PALIAS[parts[1]];
    HS.go('#/' + parts.map(encodeURIComponent).join('/'), true);
    return;
  }

  // Every page but Home and the directories reads the box scores, which arrive just after the first
  // page (HS.boxes draws it again then). Until they are in, the page the server already drew for
  // this address stays on screen as it is; a page opened from a link meanwhile says it is loading.
  if (!HS.hasBoxes() && !ROUTE_NO_BOX.test(parts[0] || '')) {
    const first = !ROUTE_DRAWN && HS.PATHS && location.pathname === HS.BOOT_PATH && !!app.firstElementChild;
    ROUTE_DRAWN = true;
    if (first) return;
    app.innerHTML = renderNav('hub', null, '') + '<main id="main" tabindex="-1"><div class="page"><div class="page-head"><div><h1 class="page-title">Loading…</h1></div></div></div></main>' + renderFooter();
    window.scrollTo(0, 0);
    return;
  }
  ROUTE_DRAWN = true;
  if (typeof fbFromUrl === 'function') fbFromUrl();   // filters written in the address (?series=…)

  if (parts.length === 0 || parts[0] === 'home') {
    // Home is the front door: live games when there are any, otherwise what's next and what just happened
    state = 'home'; body = renderHome();
  } else if (parts[0] === 'live' && parts[1]) {
    state = 'live'; body = renderLiveGame(parts[1]);
  } else if (parts[0] === 'scout' && scoutAdmin()) {
    // Tools › Scout room (admin only): the film-tagging tool fills the window (app4zg_scout.js)
    if (!scoutFrameKept(scoutSrc(false, parts[1]))) app.innerHTML = renderScoutRoom(parts[1]);
    if (typeof hsApplyMeta === 'function') hsApplyMeta(HS.hash());
    return;
  } else if (parts[0] === 'scout' || parts[0] === 'scouting') {
    // Tools › Scouting reports (admin only): every scouted game, or one (app4zg_scout.js)
    if (scoutAdmin() && parts[0] === 'scouting' && scoutFrameKept(scoutSrc(true, parts[1]))) return;
    state = 'scouting';
    body = !scoutAdmin() ? scoutGate(parts[0] === 'scout' ? 'Scout room' : 'Scouting reports') : renderScouting(parts[1]);
  } else if (parts[0] === 'watch' && parts[1]) {
    // the Watch page fills the screen: the video and the game's numbers, no site bar or footer
    app.innerHTML = renderWatch(parts[1]);
    window.scrollTo(0, 0);
    return;
  } else if (parts[0] === 'me') {
    // My page, and a verified player's edit page; both private to the signed-in person
    state = 'me'; body = parts[1] === 'edit' ? renderMeEdit() : renderMe();
  } else if (parts[0] === 'admin') {
    state = 'me'; body = renderAdmin();
  } else if (parts[0] === 'privacy') {
    state = 'me'; body = renderPrivacy();
  } else if (parts[0] === 'players') {
    state = 'global-players'; body = renderGlobalPlayers();
  } else if (parts[0] === 'competitions') {
    state = 'hub'; body = renderHub();
  } else if (parts[0] === 'teams') {
    state = 'teams-hub'; body = renderTeamsHub();
  } else if (parts[0] === 't' && parts[1]) {
    state = 'team-global'; body = renderTeamGlobal(decodeURIComponent(parts[1]), parts[2]);
  } else if (parts[0] === 'stats') {
    // Stats: Lineups and Clutch, chosen from the menu under the Stats tab
    state = 'stats'; tab = parts[1] === 'clutch' ? 'clutch' : 'lineups'; body = renderStats(tab);
  } else if (parts[0] === 'cf' && parts[1]) {
    state = 'cfam'; body = renderFamily(parts[1]);
  } else if (parts[0] === 'shift') {
    // Tools › Stat Line Shift: one player's line with and without chosen teammates (app4ze_shift.js)
    state = 'shift'; body = renderShift();
  } else if (parts[0] === 'wowy') {
    // Tools › WOWY: on/off combinations of up to five players (app4zd_wowy.js)
    state = 'wowy'; body = renderWowy();
  } else if (parts[0] === 'records') {
    state = 'records'; body = renderRecords();
  } else if (parts[0] === 'mbl') {
    // the current MBL season on one page (app4zh_mbl.js)
    state = 'mbl'; body = renderMbl();
  } else if (parts[0] === 'milestones') {
    state = 'milestones'; body = renderMilestones();
  } else if (parts[0] === 'formulas') {
    state = 'formulas'; body = renderFormulas();
  } else if (parts[0] === 'help') {
    // How to use, What the numbers mean, Where the data comes from (app4zm_help.js)
    state = 'help'; body = renderHelp(parts[1], parts[2]);
  } else if (parts[0] === 'compare' && parts[1] === 'lineups') {
    // Compare › Lineups: two teams' fives against each other, in one competition
    state = 'compare'; body = renderCmpLineups(parts[2]);
  } else if (parts[0] === 'compare') {
    state = 'compare';
    COMPARE.a = parts[1] && PERSONS[parts[1]] ? parts[1] : '';
    COMPARE.b = parts[2] && PERSONS[parts[2]] ? parts[2] : '';
    body = renderCompare();
  } else if (parts[0] === 'p' && parts[1]) {
    state = 'player'; tab = parts[2] || 'overview'; body = renderPlayer(parts[1], tab);
  } else if (parts[0] === 'c' && parts[1] && COMP_BY_ID[parts[1]]) {
    cid = parts[1];
    const r = parts.slice(2);
    if (r.length === 0) { state = 'dashboard'; body = renderCompDash(cid); }
    else if (r[0] === 'standings') { state = 'standings'; body = renderStandings(cid); }
    else if (r[0] === 'schedule') { state = 'schedule'; tab = (r[1] === 'upcoming' ? 'upcoming' : 'results'); body = renderSchedule(cid, tab); }
    else if (r[0] === 'teams') { state = 'teams'; body = renderTeams(cid); }
    else if (r[0] === 'team' && r[1]) { state = 'teams'; tab = r[2] || 'roster'; body = renderTeam(cid, r[1], tab); }
    else if (r[0] === 'players') { state = 'players'; body = renderCompPlayers(cid); }
    else if (r[0] === 'leaders') { state = 'leaders'; body = renderLeaders(cid); }
    else if (r[0] === 'box' && r[1]) { state = 'schedule'; body = renderBox(cid, r[1]); }
    else if (r[0] === 'pbp' && r[1]) { state = 'schedule'; body = renderPBP(cid, r[1]); }
    else if (r[0] === 'manalysis' && r[1]) { state = 'schedule'; body = renderMatchAnalysis(cid, r[1]); }
    else if (r[0] === 'shots' && r[1]) { state = 'schedule'; body = renderMatchShots(cid, r[1]); }
    else if (r[0] === 'postgame' && r[1]) { state = 'schedule'; body = renderMatchPostgame(cid, r[1]); }
    else { state = 'dashboard'; body = renderCompDash(cid); }
  } else if (parts[0] === 'c') {
    state = 'notfound'; body = renderNotFound(parts[1]);
  } else {
    body = renderHub();
  }

  app.innerHTML = renderNav(state, cid, tab) + '<main id="main" tabindex="-1">' + body + '</main>' + renderFooter();
  if (samePlayer) pvKeepScroll(keepY); else window.scrollTo(0, 0);
  if (typeof afterRender === 'function') afterRender();
  if (typeof hsApplyMeta === 'function') hsApplyMeta(HS.hash());
}

function renderNotFound(id) {
  return `<div class="page">
    <div class="page-head"><div>
      <h1 class="page-title">Competition not found</h1>
      <div class="page-sub">"${esc(id || '')}" isn't a competition in this database.</div>
    </div></div>
    <div class="card"><div class="empty-row"><span class="empty-dot"></span>Browse all ${COMPS.length} competitions from the <a href="#/competitions">Competitions</a> page.</div></div>
  </div>`;
}

